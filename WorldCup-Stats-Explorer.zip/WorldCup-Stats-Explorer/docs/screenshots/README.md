# Application screenshots

This repository intentionally does not include simulated screenshots. Run the applications on Windows and add real captures here. Suggested filenames:

- `wpf-match-view.png`
- `winforms-player-stats.png`
- `settings.png`

Capture screenshots using **Win + Shift + S**. Avoid including personal notifications or unrelated windows.
