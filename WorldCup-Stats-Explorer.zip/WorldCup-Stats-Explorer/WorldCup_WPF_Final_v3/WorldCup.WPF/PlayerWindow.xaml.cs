using System.Linq;
using System.Windows;
using WorldCup.Data.Models;

namespace WorldCup.WPF
{
    public partial class PlayerWindow : Window
    {
        public PlayerWindow(Player p, Match match)
        {
            InitializeComponent();
            NameTxt.Text = p.Name;
            NumberTxt.Text = $"#{p.ShirtNumber}";
            PosTxt.Text = $"Position: {p.Position}";
            CaptainTxt.Text = p.Captain ? "Captain: Yes" : "Captain: No";

            int goals = match.HomeTeamEvents.Concat(match.AwayTeamEvents)
                .Count(ev => ev.Player == p.Name && ev.TypeOfEvent.ToLower().Contains("goal"));
            int yellows = match.HomeTeamEvents.Concat(match.AwayTeamEvents)
                .Count(ev => ev.Player == p.Name && ev.TypeOfEvent.ToLower().Contains("yellow"));

            GoalsTxt.Text = $"Goals in match: {goals}";
            CardsTxt.Text = $"Yellow cards: {yellows}";
        }
    }
}