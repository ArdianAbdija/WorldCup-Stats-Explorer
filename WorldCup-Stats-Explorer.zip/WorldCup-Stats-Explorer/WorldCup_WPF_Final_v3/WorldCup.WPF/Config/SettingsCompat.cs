using System;
using System.IO;
using WorldCup.Data.Config;

namespace WorldCup.WPF.Config
{
    public static class SettingsCompat
    {
        public static string AppDataDir => Path.Combine(AppContext.BaseDirectory, "appdata");
        public static string SettingsPath => Path.Combine(AppDataDir, "settings.txt");
        public static string FavoriteTeamPath => Path.Combine(AppDataDir, "favorite_team.txt");
        public static string FavoritePlayersPath => Path.Combine(AppDataDir, "favorite_players.txt");

        public static (Gender gender, Lang lang) LoadOrDefault()
        {
            try
            {
                Directory.CreateDirectory(AppDataDir);
                if (File.Exists(SettingsPath))
                {
                    var t = File.ReadAllText(SettingsPath);
                    var gender = t.Contains("gender=1") ? Gender.Women : Gender.Men;
                    var lang = t.Contains("lang=hr") ? Lang.Hr : Lang.En;
                    return (gender, lang);
                }

                var wf = TryFindWinFormsAppData();
                if (!string.IsNullOrEmpty(wf))
                {
                    var wfSettings = Path.Combine(wf!, "settings.txt");
                    if (File.Exists(wfSettings))
                    {
                        var t2 = File.ReadAllText(wfSettings);
                        var gender = t2.Contains("gender=1") ? Gender.Women : Gender.Men;
                        var lang = t2.Contains("lang=hr") ? Lang.Hr : Lang.En;
                        Save(gender, lang);
                        return (gender, lang);
                    }
                }
            }
            catch { }

            return (Gender.Men, Lang.En);
        }

        public static void Save(Gender gender, Lang lang)
        {
            Directory.CreateDirectory(AppDataDir);
            var langCode = lang == Lang.Hr ? "hr" : "en";
            File.WriteAllText(SettingsPath, $"gender={(int)gender}\nlang={langCode}");
        }

        public static void SyncFavoritesFromWinFormsIfExists()
        {
            try
            {
                Directory.CreateDirectory(AppDataDir);
                var wf = TryFindWinFormsAppData();
                if (string.IsNullOrEmpty(wf)) return;

                var ft = Path.Combine(wf!, "favorite_team.txt");
                var fp = Path.Combine(wf!, "favorite_players.txt");
                if (File.Exists(ft) && !File.Exists(FavoriteTeamPath))
                    File.Copy(ft, FavoriteTeamPath, overwrite: false);
                if (File.Exists(fp) && !File.Exists(FavoritePlayersPath))
                    File.Copy(fp, FavoritePlayersPath, overwrite: false);
            }
            catch { }
        }

        public static void SaveFavoriteTeam(string? fifaCode)
        {
            Directory.CreateDirectory(AppDataDir);

            if (string.IsNullOrWhiteSpace(fifaCode))
            {
                if (File.Exists(FavoriteTeamPath)) File.Delete(FavoriteTeamPath);
            }
            else
            {
                File.WriteAllText(FavoriteTeamPath, fifaCode.Trim());
            }

            var wf = TryFindWinFormsAppData();
            if (!string.IsNullOrEmpty(wf))
            {
                try
                {
                    var wfFt = Path.Combine(wf!, "favorite_team.txt");
                    if (string.IsNullOrWhiteSpace(fifaCode))
                    {
                        if (File.Exists(wfFt)) File.Delete(wfFt);
                    }
                    else
                    {
                        File.WriteAllText(wfFt, fifaCode!.Trim());
                    }
                }
                catch { }
            }
        }

        public static void SaveFavoritePlayers(string content)
        {
            Directory.CreateDirectory(AppDataDir);
            File.WriteAllText(FavoritePlayersPath, content ?? string.Empty);

            var wf = TryFindWinFormsAppData();
            if (!string.IsNullOrEmpty(wf))
            {
                try
                {
                    File.WriteAllText(Path.Combine(wf!, "favorite_players.txt"), content ?? string.Empty);
                }
                catch { }
            }
        }

        public static void ClearFavorites()
        {
            try
            {
                if (File.Exists(FavoriteTeamPath)) File.Delete(FavoriteTeamPath);
                if (File.Exists(FavoritePlayersPath)) File.Delete(FavoritePlayersPath);

                var wf = TryFindWinFormsAppData();
                if (!string.IsNullOrEmpty(wf))
                {
                    var ft = Path.Combine(wf!, "favorite_team.txt");
                    var fp = Path.Combine(wf!, "favorite_players.txt");
                    if (File.Exists(ft)) File.Delete(ft);
                    if (File.Exists(fp)) File.Delete(fp);
                }
            }
            catch { }
        }

        private static string? TryFindWinFormsAppData()
        {
            try
            {
                var dir = new DirectoryInfo(AppContext.BaseDirectory);
                for (int i = 0; i < 8 && dir != null; i++)
                {
                    var guess = Path.Combine(dir.FullName, "WorldCup.WinForms", "bin", "Debug", "net8.0-windows", "appdata");
                    if (Directory.Exists(guess)) return guess;
                    dir = dir.Parent!;
                }
            }
            catch { }
            return null;
        }
    }
}
