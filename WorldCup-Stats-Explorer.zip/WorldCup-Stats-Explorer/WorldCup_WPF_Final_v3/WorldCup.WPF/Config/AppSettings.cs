using System;
using System.IO;
using System.Text.Json;
using WorldCup.Data.Config;

namespace WorldCup.WPF.Config
{
    public enum DisplayMode { Fullscreen, Windowed }
    public sealed class AppSettings
    {
        public string Title { get; set; } = "World Cup Viewer";
        public Lang Language { get; set; } = Lang.En;
        public Gender Gender { get; set; } = Gender.Men;
        public DataMode Mode { get; set; } = DataMode.Api;
        public DisplayMode Display { get; set; } = DisplayMode.Windowed;
        public int Width { get; set; } = 1280;
        public int Height { get; set; } = 800;


        public static string FilePath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "WorldCup_Abdija", "settings.json");

        public void Save()
        {
            var dir = Path.GetDirectoryName(FilePath)!;
            Directory.CreateDirectory(dir);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions{WriteIndented = true}));
        }

        public static AppSettings LoadOrDefault()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var json = File.ReadAllText(FilePath);
                    var obj = JsonSerializer.Deserialize<AppSettings>(json);
                    if (obj != null) return obj;
                }
            }
            catch { }
            return new AppSettings();
        }

        public DataConfig ToDataConfig() => new DataConfig
        {
            Language = Language,
            Gender = Gender,
            Mode = Mode
        };
    }
}