using System;
using System.Windows.Input;

namespace WorldCup.WPF.Mvvm
{
    public sealed class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Func<object?, bool>? _can;
        public RelayCommand(Action<object?> execute, Func<object?, bool>? can = null)
        {
            _execute = execute; _can = can;
        }
        public bool CanExecute(object? p) => _can?.Invoke(p) ?? true;
        public void Execute(object? p) => _execute(p);
        public event EventHandler? CanExecuteChanged;
        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}