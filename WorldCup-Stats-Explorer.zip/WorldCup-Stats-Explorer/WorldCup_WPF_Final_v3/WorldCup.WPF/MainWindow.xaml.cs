using WorldCup.WPF.Controls;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using WorldCup.Data.Models;
using WorldCup.WPF.Config;
using WorldCup.WPF.ViewModels;

namespace WorldCup.WPF
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _vm;
        private const double PlayerCardWidth = 60;  
        private const double PlayerCardHeight = 40; 
        private const double PlayerCardScale = 0.5;
        public MainWindow()
        {


            var settings = AppSettings.LoadOrDefault();
            InitializeComponent();

            Title = settings.Title;
            if (settings.Display == DisplayMode.Fullscreen) { WindowStyle = WindowStyle.None; WindowState = WindowState.Maximized; }
            else { Width = settings.Width; Height = settings.Height; }

            _vm = new MainViewModel(settings);
            DataContext = _vm;

            Loaded += async (_, __) =>
            {
                LoadingOverlay.Visibility = Visibility.Visible;
                var (g, l) = SettingsCompat.LoadOrDefault();
                SettingsCompat.SyncFavoritesFromWinFormsIfExists();
                _vm.ApplyGenderAndLanguage(g, l);
                await _vm.InitializeAsync();
                LoadingOverlay.Visibility = Visibility.Collapsed;

                TeamABox.ItemsSource = _vm.Teams;
                _vm.PropertyChanged += VmOnPropertyChanged;
                ((INotifyCollectionChanged)_vm.HomeXI).CollectionChanged += (_, __2) => RenderPitch();
                ((INotifyCollectionChanged)_vm.AwayXI).CollectionChanged += (_, __2) => RenderPitch();

               

    };
        }

        private void VmOnPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(MainViewModel.SelectedMatch))
            {
                RenderPitch();
            }
            else if (e.PropertyName == nameof(MainViewModel.Settings))
            {
                Title = _vm.WindowTitle;
            }
        }

        private void ClearPitch()
        {
            Pitch.HomeLayer.Children.Clear();
            Pitch.AwayLayer.Children.Clear();
        }

        private void RenderPitch()
        {
            ClearPitch();

            PlaceTeam(Pitch.HomeLayer, _vm.HomeXI, true);
            PlaceTeam(Pitch.AwayLayer, _vm.AwayXI, false);
        }
        

        private void PlaceTeam(Canvas canvas, System.Collections.Generic.IEnumerable<Player> players, bool isHome)
        {
            canvas.ClipToBounds = true; // cards dont bleed out of pitch


            if (players == null) return;
            double width = (canvas.Parent as FrameworkElement)?.ActualWidth ?? 400;
            double height = (canvas.Parent as FrameworkElement)?.ActualHeight ?? 400;

            var gk = players.Where(p => p.Position.StartsWith("G", StringComparison.OrdinalIgnoreCase)).ToList();
            var df = players.Where(p => p.Position.StartsWith("D", StringComparison.OrdinalIgnoreCase)).ToList();
            var mf = players.Where(p => p.Position.StartsWith("M", StringComparison.OrdinalIgnoreCase)).ToList();
            var fw = players.Where(p => p.Position.StartsWith("F", StringComparison.OrdinalIgnoreCase)).ToList();

            // Top-half (Team A / isHome = true): GK near top goal ? FW just above halfway
            const double TOP_GK = 0.10, TOP_DF = 0.20, TOP_MF = 0.30, TOP_FW = 0.40;
            // Bottom-half (Team B / isHome = false): FW just below halfway ? GK near bottom goal
            const double BOT_GK = 0.90, BOT_DF = 0.80, BOT_MF = 0.70, BOT_FW = 0.60;

            PlaceRow(canvas, gk, isHome ? TOP_GK : BOT_GK, isHome);
            PlaceRow(canvas, df, isHome ? TOP_DF : BOT_DF, isHome);
            PlaceRow(canvas, mf, isHome ? TOP_MF : BOT_MF, isHome);
            PlaceRow(canvas, fw, isHome ? TOP_FW : BOT_FW, isHome);





        }

        private void PlaceRow(Canvas canvas, System.Collections.Generic.IList<Player> row, double yRatio, bool isHome)
        {
            


            if (row.Count == 0) return;

            double width = (canvas.Parent as FrameworkElement)?.ActualWidth ?? 400;
            double height = (canvas.Parent as FrameworkElement)?.ActualHeight ?? 400;

            int n = row.Count;
            for (int i = 0; i < n; i++)
            {
                double x = (i + 1) * (width / (n + 1));
                double y = yRatio * height;

                var ctrl = new PlayerBadge
                {
                    DataContext = row[i],
                    IsHome = isHome,                  
                    Opacity = 0,
                    Margin = new Thickness(0, -8, 0, 8)
                };

                ctrl.MouseLeftButtonUp += (s, e) => _vm.PlayerClicked.Execute(row[i]);
                Canvas.SetLeft(ctrl, x - PlayerCardWidth * PlayerCardScale);
                Canvas.SetTop(ctrl, y - PlayerCardHeight * PlayerCardScale);


                canvas.Children.Add(ctrl);

                var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(300));
                ctrl.BeginAnimation(UIElement.OpacityProperty, fade);
                var slide = new ThicknessAnimation(new Thickness(0, -8, 0, 8), new Thickness(0), TimeSpan.FromMilliseconds(300));
                ctrl.BeginAnimation(FrameworkElement.MarginProperty, slide);



            }
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            var before = _vm.Settings;
            _vm.OpenSettings.Execute(null);
            var after = _vm.Settings;
            if (after.Display == DisplayMode.Fullscreen) { WindowStyle = WindowStyle.None; WindowState = WindowState.Maximized; }
            else { WindowStyle = WindowStyle.SingleBorderWindow; WindowState = WindowState.Normal; Width = after.Width; Height = after.Height; }
            Title = after.Title;
        }

        private void TeamABox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _vm.TeamA = TeamABox.SelectedItem as TeamResult;
            TeamBBox.ItemsSource = null;
            ClearPitch();

            var matches = _vm.HeadToHeadMatches.ToList();
            var codes = matches.Where(m => _vm.TeamA != null)
                               .Select(m => m.HomeTeam.Code == _vm.TeamA!.FifaCode ? m.AwayTeam.Code : m.HomeTeam.Code)
                               .Distinct().ToList();
            var opps = _vm.Teams.Where(t => codes.Contains(t.FifaCode)).OrderBy(t => t.Country).ToList();
            TeamBBox.ItemsSource = opps;
        }

        private void TeamBBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _vm.TeamB = TeamBBox.SelectedItem as TeamResult;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var res = MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButton.YesNo);
            if (res != MessageBoxResult.Yes) e.Cancel = true;
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape) { Close(); e.Handled = true; }
        }
    }
}