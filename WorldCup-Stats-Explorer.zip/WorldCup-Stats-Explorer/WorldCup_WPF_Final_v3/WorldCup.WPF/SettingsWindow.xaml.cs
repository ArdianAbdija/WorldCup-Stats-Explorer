using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WorldCup.Data.Config;
using WorldCup.WPF.Config;
using WorldCup.WPF.Localization;

namespace WorldCup.WPF
{
    public partial class SettingsWindow : Window
    {
        public AppSettings Settings { get; private set; }
        public SettingsWindow(AppSettings current)
        {
            InitializeComponent();
            Settings = current;

            // init UI from current
            TitleBox.Text = Settings.Title;
            LangBox.SelectedIndex = Settings.Language == Lang.Hr ? 1 : 0;
            GenderBox.SelectedIndex = Settings.Gender == Gender.Women ? 1 : 0;
            ModeBox.SelectedIndex = Settings.Mode == DataMode.LocalJson ? 1 : 0;
            FullscreenCheck.IsChecked = Settings.Display == DisplayMode.Fullscreen;
            WidthBox.Text = Settings.Width.ToString();
            HeightBox.Text = Settings.Height.ToString();
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            // confirm dialog
            if (MessageBox.Show("Save changes?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;

            Settings.Title = TitleBox.Text.Trim();

            // Fixed block: use Tag and compare string, then assign enum value
            Settings.Language = ((ComboBoxItem)LangBox.SelectedItem).Tag?.ToString() == "Hr" ? Lang.Hr : Lang.En;

            Settings.Gender = ((string)((ComboBoxItem)GenderBox.SelectedItem).Tag) == "Women" ? Gender.Women : Gender.Men;
            Settings.Mode = ((string)((ComboBoxItem)ModeBox.SelectedItem).Tag) == "LocalJson" ? DataMode.LocalJson : DataMode.Api;
            Settings.Display = FullscreenCheck.IsChecked == true ? DisplayMode.Fullscreen : DisplayMode.Windowed;

            if (int.TryParse(WidthBox.Text, out var w)) Settings.Width = w;
            if (int.TryParse(HeightBox.Text, out var h)) Settings.Height = h;

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter) Confirm_Click(sender, e);
            else if (e.Key == System.Windows.Input.Key.Escape) Cancel_Click(sender, e);
        }
    }
}