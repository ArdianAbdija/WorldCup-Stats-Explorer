using WorldCup.Data.Models;

namespace WorldCup.WPF.Models
{
    public sealed class PlayerCardInfo
    {
        public Player Player { get; }
        public int YellowCards { get; }
        public int RedCards { get; }

        public string DisplayName => $"{Player.Name}  {Player.ShirtNumber}".Trim();

        public PlayerCardInfo(Player p, int yellows, int reds)
        {
            Player = p;
            YellowCards = yellows;
            RedCards = reds;
        }
    }
}