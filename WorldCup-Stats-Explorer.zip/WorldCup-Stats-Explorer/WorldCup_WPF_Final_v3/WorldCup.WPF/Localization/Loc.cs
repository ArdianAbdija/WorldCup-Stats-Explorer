using System;
using System.Globalization;
using System.Windows;
using System.Windows.Markup;
using WorldCup.Data.Config;

namespace WorldCup.WPF.Localization
{
    public static class Loc
    {
        public static void ApplyLanguage(Lang lang)
        {
            var code = lang == Lang.Hr ? "hr" : "en";
            var culture = new CultureInfo(code);
            CultureInfo.DefaultThreadCurrentUICulture = culture;
            CultureInfo.DefaultThreadCurrentCulture = culture;

            var dict = new ResourceDictionary();
            var path = $"Resources/Strings{(lang == Lang.Hr ? ".hr" : "")}.xaml";
            dict.Source = new Uri(path, UriKind.Relative);
            Application.Current.Resources.MergedDictionaries.Clear();
            Application.Current.Resources.MergedDictionaries.Add(dict);
        }
    }
}