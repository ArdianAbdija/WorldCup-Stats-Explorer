// PlayerBadge.xaml.cs
using System.Windows;
using System.Windows.Controls;

namespace WorldCup.WPF.Controls
{
    public partial class PlayerBadge : UserControl
    {
        public PlayerBadge()
        {
            InitializeComponent();
        }

        public bool IsHome
        {
            get => (bool)GetValue(IsHomeProperty);
            set => SetValue(IsHomeProperty, value);
        }

        public static readonly DependencyProperty IsHomeProperty =
            DependencyProperty.Register(nameof(IsHome), typeof(bool), typeof(PlayerBadge),
                new PropertyMetadata(true));
    }
}
