﻿using System.Windows;
using System.Windows.Controls;

namespace WorldCup.WPF.Controls
{
    public class AspectRatioContainer : Decorator
    {
        public double Ratio
        {
            get => (double)GetValue(RatioProperty);
            set => SetValue(RatioProperty, value);
        }

        public static readonly DependencyProperty RatioProperty =
            DependencyProperty.Register(nameof(Ratio), typeof(double), typeof(AspectRatioContainer),
                new FrameworkPropertyMetadata(1.0, FrameworkPropertyMetadataOptions.AffectsMeasure));

        protected override Size MeasureOverride(Size constraint)
        {
            if (Child == null) return new Size();

            Child.Measure(constraint);

            double width = constraint.Width;
            double height = constraint.Height;

            if (double.IsInfinity(width) && double.IsInfinity(height))
            {
                width = Child.DesiredSize.Width;
                height = Child.DesiredSize.Height;
            }
            else if (double.IsInfinity(width))
            {
                width = height * Ratio;
            }
            else if (double.IsInfinity(height))
            {
                height = width / Ratio;
            }
            else
            {
                if (width / height > Ratio)
                    width = height * Ratio;
                else
                    height = width / Ratio;
            }

            return new Size(width, height);
        }

        protected override Size ArrangeOverride(Size arrangeSize)
        {
            double width = arrangeSize.Width;
            double height = arrangeSize.Height;

            if (width / height > Ratio)
                width = height * Ratio;
            else
                height = width / Ratio;

            double x = (arrangeSize.Width - width) / 2;
            double y = (arrangeSize.Height - height) / 2;

            Rect rect = new Rect(x, y, width, height);
            Child?.Arrange(rect);

            return arrangeSize;
        }
    }
}
