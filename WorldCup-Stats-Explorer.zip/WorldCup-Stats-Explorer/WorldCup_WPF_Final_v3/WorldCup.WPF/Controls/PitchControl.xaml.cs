﻿using System.Windows.Controls;

namespace WorldCup.WPF.Controls
{
    public partial class PitchControl : UserControl
    {
        public PitchControl()
        {
            InitializeComponent();
        }

        // Optional: expose canvases if you need to access them from MainWindow code-behind/VM
        public Canvas HomeLayer => HomeCanvas;
        public Canvas AwayLayer => AwayCanvas;
    }
}
