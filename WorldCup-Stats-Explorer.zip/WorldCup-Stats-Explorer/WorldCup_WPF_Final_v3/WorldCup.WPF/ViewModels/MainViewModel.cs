using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using WorldCup.Data.Models;
using WorldCup.Data.Services;
using WorldCup.WPF.Localization;
using WorldCup.WPF.Mvvm;
using WorldCup.WPF.Models;
using WorldCup.WPF.Config;        // <-- make sure this using is at the top
using WorldCup.Data.Config;       // <-- and this too


namespace WorldCup.WPF.ViewModels
{
    public sealed class MainViewModel : ViewModelBase
    {
        internal WorldCupDataService _svc;
        private readonly CancellationTokenSource _cts = new();

        public ObservableCollection<TeamResult> Teams { get; } = new();
        public ObservableCollection<TeamResult> Opponents { get; } = new();
        public ObservableCollection<Match> HeadToHeadMatches { get; } = new();

        private TeamResult? _teamA;
        public TeamResult? TeamA { get => _teamA; set { Set(ref _teamA, value); _ = LoadOpponentsAsync(); Raise(nameof(TeamALabel)); Raise(nameof(TeamAFlagPath)); Raise(nameof(TeamAFormation)); } }

        private TeamResult? _teamB;
        public TeamResult? TeamB { get => _teamB; set { Set(ref _teamB, value); _ = UpdateMatchAsync(); Raise(nameof(TeamBLabel)); Raise(nameof(TeamBFlagPath)); Raise(nameof(TeamBFormation)); } }

        private Match? _selectedMatch;
        public Match? SelectedMatch { get => _selectedMatch; set { Set(ref _selectedMatch, value); UpdateLineupsFromMatch(); Raise(nameof(KickoffLabel)); } }

        private bool _isLoading;
        public bool IsLoading { get => _isLoading; set => Set(ref _isLoading, value); }

        // Pitch elevens
        public ObservableCollection<Player> HomeXI { get; } = new();
        public ObservableCollection<Player> AwayXI { get; } = new();

        // Side lists with cards
        public ObservableCollection<PlayerCardInfo> HomeLineup { get; } = new();
        public ObservableCollection<PlayerCardInfo> AwayLineup { get; } = new();
        public ObservableCollection<PlayerCardInfo> HomeBench { get; } = new();
        public ObservableCollection<PlayerCardInfo> AwayBench { get; } = new();

        public RelayCommand OpenSettings { get; }
        public RelayCommand ShowTeamAInfo { get; }
        public RelayCommand ShowTeamBInfo { get; }
        public RelayCommand PlayerClicked { get; }

        public AppSettings Settings { get; private set; }
        public string WindowTitle => Settings.Title;

        public string TeamALabel => TeamA != null ? $"{TeamA.Country}" : "";
        public string TeamBLabel => TeamB != null ? $"{TeamB.Country}" : "";
        public string TeamAFlagPath => TeamA != null ? $"Assets/Flags/{TeamA.FifaCode}.png" : null;
        public string TeamBFlagPath => TeamB != null ? $"Assets/Flags/{TeamB.FifaCode}.png" : null;
        public string TeamAFormation => SelectedMatch?.HomeTeamStatistics?.Tactics ?? "";
        public string TeamBFormation => SelectedMatch?.AwayTeamStatistics?.Tactics ?? "";
        public string KickoffLabel => SelectedMatch?.DateTime?.ToLocalTime().ToString("HH:mm\n dd MMM yyyy") ?? "";

        public MainViewModel(AppSettings settings)
        {
            Settings = settings;
            Loc.ApplyLanguage(settings.Language);
            _svc = new WorldCupDataService(settings.ToDataConfig());

            OpenSettings = new RelayCommand(_ => OpenSettingsWindow());
            ShowTeamAInfo = new RelayCommand(_ => ShowTeamInfo(TeamA));
            ShowTeamBInfo = new RelayCommand(_ => ShowTeamInfo(TeamB));
            PlayerClicked = new RelayCommand(p =>
            {
                if (p is Player pl && SelectedMatch != null)
                {
                    var w = new PlayerWindow(pl, SelectedMatch);
                    w.Owner = Application.Current.MainWindow;
                    w.ShowDialog();
                }
            });
        }

        public async Task InitializeAsync()
        {
            await LoadTeamsAsync();
        }

        private async Task LoadTeamsAsync()
        {
            IsLoading = true;
            try
            {
                Teams.Clear();
                var teams = await _svc.GetTeamResultsAsync(_cts.Token);
                foreach (var t in teams.OrderBy(t => t.Country)) Teams.Add(t);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error"); }
            finally { IsLoading = false; }
        }

        private async Task LoadOpponentsAsync()
        {
            HeadToHeadMatches.Clear();
            Opponents.Clear();
            TeamB = null;
            SelectedMatch = null;
            ClearAllLists();

            if (TeamA == null) return;

            IsLoading = true;
            try
            {
                // Try by FIFA code first; if your data service expects Country, fallback.
                var matches = await _svc.GetMatchesByCountryAsync(TeamA.FifaCode, _cts.Token);
                if (matches == null || matches.Count == 0)
                    matches = await _svc.GetMatchesByCountryAsync(TeamA.Country, _cts.Token);

                //System.Windows.MessageBox.Show($"Loaded matches: {matches?.Count ?? 0}");

                // Build opponents straight from the matches (no dependency on 'Teams')
                var opps = matches
                   

                    .Select(m => m.HomeTeam.Code == TeamA.FifaCode ? m.AwayTeam : m.HomeTeam)
                    .Where(t => t != null && !string.IsNullOrWhiteSpace(t.Code))
                    .GroupBy(t => t.Code)
                    .Select(g => new TeamResult
                    {
                        FifaCode = g.Key,
                        Country = g.First().Country
                    })
                    .OrderBy(tr => tr.Country)
                    .ToList();
               
              


                foreach (var tr in opps) Opponents.Add(tr);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                IsLoading = false;
            }
            if (TeamB is null) TeamB = Opponents.FirstOrDefault();

            System.Windows.MessageBox.Show(
        $"Opponents count: {Opponents.Count}\n" +
        string.Join(", ", Opponents.Select(o => o.Country)));
        }
       




        private async Task UpdateMatchAsync()
        {
            SelectedMatch = null;
            ClearAllLists();
            if (TeamA == null || TeamB == null) return;

            IsLoading = true;
            try
            {
                var matches = await _svc.GetMatchesAsync(_cts.Token);
                var h2h = matches
                    .Where(m => (m.HomeTeam.Code == TeamA.FifaCode && m.AwayTeam.Code == TeamB.FifaCode) ||
                                (m.HomeTeam.Code == TeamB.FifaCode && m.AwayTeam.Code == TeamA.FifaCode))
                    .OrderByDescending(m => m.DateTime ?? DateTime.MinValue)
                    .ToList();
                SelectedMatch = h2h.FirstOrDefault();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error"); }
            finally { IsLoading = false; }
        }

        private void ClearAllLists()
        {
            HomeXI.Clear(); AwayXI.Clear();
            HomeLineup.Clear(); AwayLineup.Clear();
            HomeBench.Clear(); AwayBench.Clear();
        }

        private void UpdateLineupsFromMatch()
        {
            ClearAllLists();
            var m = SelectedMatch;
            if (m == null) return;

            void Fill(TeamStatistics? stats, bool isHome)
            {
                if (stats == null) return;
                var events = (SelectedMatch!.HomeTeamEvents ?? Enumerable.Empty<TeamEvent>())
                    .Concat(SelectedMatch!.AwayTeamEvents ?? Enumerable.Empty<TeamEvent>())
                    .ToList();

                var lineup = stats.StartingEleven ?? new System.Collections.Generic.List<Player>();
                var bench = stats.Substitutes ?? new System.Collections.Generic.List<Player>();

                foreach (var p in lineup) (isHome ? HomeXI : AwayXI).Add(p);

                PlayerCardInfo Make(Player p)
                {
                    int y = events.Count(e => e.Player == p.Name && e.TypeOfEvent.ToLower().Contains("yellow"));
                    int r = events.Count(e => e.Player == p.Name && e.TypeOfEvent.ToLower().Contains("red"));
                    return new PlayerCardInfo(p, y, r);
                }

                foreach (var pci in lineup.Select(Make)) (isHome ? HomeLineup : AwayLineup).Add(pci);
                foreach (var pci in bench.Select(Make)) (isHome ? HomeBench : AwayBench).Add(pci);
            }

            Fill(m.HomeTeamStatistics, true);
            Fill(m.AwayTeamStatistics, false);
        }

        private void ShowTeamInfo(TeamResult? team)
        {
            if (team == null) return;
            var w = new TeamInfoWindow(team);
            w.Owner = Application.Current.MainWindow;
            w.ShowDialog();
        }

        private void OpenSettingsWindow()
        {
            var dlg = new SettingsWindow(Settings);
            dlg.Owner = Application.Current.MainWindow;
            if (dlg.ShowDialog() == true)
            {
                Settings = dlg.Settings;
                Settings.Save();
                Loc.ApplyLanguage(Settings.Language);
                _svc = new WorldCupDataService(Settings.ToDataConfig());
                _ = LoadTeamsAsync();
                Raise(nameof(WindowTitle));
            }
        }


      
        public void ApplyGenderAndLanguage(Gender g, Lang l)
        {
            // Update your settings model only; do NOT reference non-existent fields
            Settings.Gender = g;
            Settings.Language = l;
            // If you recreate services elsewhere, do it there; keeping this minimal to avoid CS0103
        }

        public void ClearFavorites()
        {
            SettingsCompat.ClearFavorites();
            // If you keep in-memory favorite state, clear it here safely:
            // FavoriteTeam = null;  // only if FavoriteTeam property exists in this class
            // FavoritePlayers?.Clear(); // only if such a collection exists
        }


    }
}