namespace WorldCup.WPF.Services
{
    public static class ImageProvider
    {
        public static string GetPlayerImage(object player) => "pack://application:,,,/WorldCup.WPF;component/Assets/Images/player_default.png";
    }
}