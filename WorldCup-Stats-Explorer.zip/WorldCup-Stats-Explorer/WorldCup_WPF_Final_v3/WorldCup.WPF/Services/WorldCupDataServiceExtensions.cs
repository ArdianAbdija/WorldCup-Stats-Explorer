using WorldCup.Data.Config;
using WorldCup.Data.Services;

namespace WorldCup.WPF.Services
{
    public static class WorldCupDataServiceExtensions
    {
        // Small extension to swap the underlying config via reflection-safe re-init.
        public static void SetConfig(this WorldCupDataService svc, DataConfig cfg)
        {
            // WorldCupDataService has only ctor with config; simplest is to create a new one where used.
            // Here we do nothing; MainViewModel will replace the instance by creating a new WorldCupDataService.
        }
    }
}