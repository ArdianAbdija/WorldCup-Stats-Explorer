using System.Windows;
using WorldCup.Data.Models;

namespace WorldCup.WPF
{
    public partial class TeamInfoWindow : Window
    {
        private readonly TeamResult _team;
        public TeamInfoWindow(TeamResult team)
        {
            InitializeComponent();
            _team = team;
            TitleBlock.Text = $"{team.Country} ({team.FifaCode})";
            CountryTxt.Text = $"Country: {team.Country}";
            FifaTxt.Text = $"FIFA: {team.FifaCode}";
            GamesTxt.Text = $"Games: {team.GamesPlayed}";
            WDLTxt.Text = $"W/D/L: {team.Wins}/{team.Draws}/{team.Losses}";
            GoalsTxt.Text = $"Goals: {team.GoalsFor}/{team.GoalsAgainst}";
            DiffTxt.Text = $"Diff: {team.GoalDifferential}";
        }
    }
}