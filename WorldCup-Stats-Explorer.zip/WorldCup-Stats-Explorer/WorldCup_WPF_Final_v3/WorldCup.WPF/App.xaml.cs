using System.Windows;

namespace WorldCup.WPF
{
    public partial class App : Application
    {
    }
}