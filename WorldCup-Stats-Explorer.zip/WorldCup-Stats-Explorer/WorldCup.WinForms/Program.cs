using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using WorldCup.Data.Config;
using WorldCup.Data.Services;
using WorldCup.WinForms.Forms;

namespace WorldCup.WinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // settings file
            string appDataDir = Path.Combine(AppContext.BaseDirectory, "appdata");
            string settingsPath = Path.Combine(appDataDir, "settings.txt");
            Directory.CreateDirectory(appDataDir);

            Gender gender;
            Lang language;

            if (!File.Exists(settingsPath))
            {
                var initial = new DataConfig { Mode = DataMode.Api, Gender = Gender.Men, Language = Lang.En };
                using var sf = new SettingsForm(initial);
                if (sf.ShowDialog() != DialogResult.OK) return;

                gender = sf.Config.Gender;
                language = sf.Config.Language;

                File.WriteAllText(settingsPath, $"gender={(int)gender}\nlang={(language == Lang.Hr ? "hr" : "en")}");
            }
            else
            {
                var lines = File.ReadAllLines(settingsPath);

                var gLine = lines.FirstOrDefault(l => l.StartsWith("gender=", StringComparison.OrdinalIgnoreCase)) ?? "gender=0";
                gender = (gLine.Split('=')[1].Trim() == "1") ? Gender.Women : Gender.Men;

                var lLine = lines.FirstOrDefault(l => l.StartsWith("lang=", StringComparison.OrdinalIgnoreCase)) ?? "lang=en";
                var code = lLine.Split('=')[1].Trim().ToLowerInvariant();
                language = code == "hr" ? Lang.Hr : Lang.En;
            }

            // Optional: set formatting culture (UI text is handled by Localizer in MainForm)
            var culture = new CultureInfo(language == Lang.Hr ? "hr-HR" : "en-US");
            Thread.CurrentThread.CurrentUICulture = culture;
            Thread.CurrentThread.CurrentCulture = culture;

            // Build service: API primary; LocalJson fallback handled inside WorldCupDataService
            var cfg = new DataConfig { Mode = DataMode.Api, Gender = gender, Language = language };
            var service = new WorldCupDataService(cfg);

            Application.Run(new MainForm(service));
        }
    }
}
