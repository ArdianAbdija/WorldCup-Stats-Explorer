﻿using System.Collections.Generic;
using WorldCup.Data.Config; // for Lang enum

namespace WorldCup.WinForms.Localization
{
    public static class Localizer
    {
        private static Lang _lang = Lang.En;

        // English strings
        private static readonly Dictionary<string, string> En = new()
        {
            ["AppTitle"] = "World Cup",
            ["Settings"] = "Settings",
            ["LoadPlayers"] = "Load Players",
            ["Goals"] = "Goals",
            ["YellowCards"] = "Yellow Cards",
            ["Attendance"] = "Attendance",
            ["Ranking"] = "Ranking",
            ["Limit"] = "Limit",
            ["Error"] = "Error",
            ["Confirm"] = "Confirm",
            ["MaxFavoritesMsg"] = "You can select at most 3 favorites.",
            ["ExitConfirm"] = "Are you sure you want to exit?",
            ["Player"] = "Player",
            ["Location"] = "Location",
            ["AttendanceCol"] = "Attendance",
            ["HomeVsAway"] = "Home vs Away",
            ["Print"] = "Print"
        };

        // Croatian strings
        private static readonly Dictionary<string, string> Hr = new()
        {
            ["AppTitle"] = "Svjetsko prvenstvo",
            ["Settings"] = "Postavke",
            ["LoadPlayers"] = "Učitaj igrače",
            ["Goals"] = "Golovi",
            ["YellowCards"] = "Žuti kartoni",
            ["Attendance"] = "Posjećenost",
            ["Ranking"] = "Poredak",
            ["Limit"] = "Ograničenje",
            ["Error"] = "Greška",
            ["Confirm"] = "Potvrda",
            ["MaxFavoritesMsg"] = "Možete odabrati najviše 3 favorita.",
            ["ExitConfirm"] = "Jeste li sigurni da želite izaći?",
            ["Player"] = "Igrač",
            ["Location"] = "Lokacija",
            ["AttendanceCol"] = "Posjećenost",
            ["HomeVsAway"] = "Domaći vs Gosti",
            ["Print"] = "Ispis"
        };

        public static void SetLanguage(Lang lang) => _lang = lang;

        public static string T(string key)
        {
            var dict = _lang == Lang.Hr ? Hr : En;
            return dict.TryGetValue(key, out var value) ? value : key;
        }
    }
}
