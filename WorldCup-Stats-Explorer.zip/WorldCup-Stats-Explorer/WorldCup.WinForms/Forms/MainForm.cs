using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;
using WorldCup.Data.Config;
using WorldCup.Data.Models;
using WorldCup.Data.Services;
using WorldCup.WinForms.Controls;
using WorldCup.WinForms.Forms;
using WorldCup.WinForms.Localization; // << Localizer.T()

namespace WorldCup.WinForms
{
    public partial class MainForm : Form
    {
        // Images are copied to the output root by the .csproj
        private readonly string _assetsRoot = AppContext.BaseDirectory;

        private DataConfig _cfg;
        private WorldCupDataService _svc;

        private readonly string appDataDir = Path.Combine(AppContext.BaseDirectory, "appdata");
        private readonly string settingsPath = Path.Combine(AppContext.BaseDirectory, "appdata", "settings.txt");
        private readonly string favTeamPath = Path.Combine(AppContext.BaseDirectory, "appdata", "favorite_team.txt");
        private readonly string favPlayersPath = Path.Combine(AppContext.BaseDirectory, "appdata", "favorite_players.txt");

        private List<Player> _currentPlayers = new();
        private HashSet<string> _favoriteNames = new(StringComparer.Ordinal);

        // ===== Constructor with DI =====
        public MainForm(WorldCupDataService service)
        {
            InitializeComponent();

            Directory.CreateDirectory(appDataDir);

            _svc = service;
            _cfg = service.Config; // preserve Mode chosen in Program.cs

            // Apply language via Localizer (no .resx required)
            ApplyLanguage(_cfg.Language);

            // Load teams list
            _ = LoadTeamsAsync();

            // Enable Drag & Drop on panels
            pnlFavorites.AllowDrop = true;
            pnlOthers.AllowDrop = true;
        }

        // ===== Localization (no .resx) =====
        private string L(string key) => Localizer.T(key);

        private void ApplyLanguage(Lang lang)
        {
            // Optional: keep .NET formatting consistent with the choice
            var culture = new CultureInfo(lang == Lang.Hr ? "hr-HR" : "en-US");
            Thread.CurrentThread.CurrentUICulture = culture;
            Thread.CurrentThread.CurrentCulture = culture;

            Localizer.SetLanguage(lang);
            ApplyLocalStrings();
        }

        // Set all control texts here (add lines for any other labels/buttons you have)
        private void ApplyLocalStrings()
        {
            this.Text = L("AppTitle");
            btnSettings.Text = L("Settings");
            btnLoadPlayers.Text = L("LoadPlayers");
            btnGoals.Text = L("Goals");
            btnYellows.Text = L("YellowCards");
            btnAttendance.Text = L("Attendance");
            btnPrint.Text = L("Print");

            // If you have group boxes/labels, set them here as well, e.g.:
            // grpFavorites.Text = L("Favorites");
            // lblTeam.Text      = L("Team");
        }

        private void PersistSettings(DataConfig cfg)
        {
            Directory.CreateDirectory(appDataDir);
            var langCode = cfg.Language == Lang.Hr ? "hr" : "en";
            File.WriteAllText(settingsPath, $"gender={(int)cfg.Gender}\nlang={langCode}");
        }

        // ===== Data load =====
        private async Task LoadTeamsAsync()
        {
            try
            {
                var teams = await _svc.GetTeamResultsAsync();

                // de-dupe by code, sort by country
                var ordered = teams
                    .Where(t => !string.IsNullOrWhiteSpace(t.FifaCode))
                    .GroupBy(t => t.FifaCode!)
                    .Select(g => g.First())
                    .OrderBy(t => t.Country)
                    .ToList();

                cmbTeams.Items.Clear();
                foreach (var t in ordered)
                    cmbTeams.Items.Add($"{t.Country} ({t.FifaCode})");

                // auto-select favorite team if saved
                if (File.Exists(favTeamPath))
                {
                    var fav = File.ReadAllText(favTeamPath).Trim();
                    for (int i = 0; i < cmbTeams.Items.Count; i++)
                    {
                        if (string.Equals(cmbTeams.Items[i]?.ToString(), fav, StringComparison.Ordinal))
                        { cmbTeams.SelectedIndex = i; break; }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{L("Error")}: {ex.Message}",
                                L("Error"),
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Players =====
        private async void btnLoadPlayers_Click(object sender, EventArgs e)
        {
            if (cmbTeams.SelectedItem == null) return;

            var display = cmbTeams.SelectedItem.ToString()!;
            File.WriteAllText(favTeamPath, display);

            var code = display.Split('(')[1].TrimEnd(')'); // "ENG"

            _currentPlayers = (await _svc.GetPlayersFromFirstMatchAsync(code)).ToList();

            _favoriteNames = new HashSet<string>(StringComparer.Ordinal);
            if (File.Exists(favPlayersPath))
            {
                foreach (var line in File.ReadAllLines(favPlayersPath))
                    if (!string.IsNullOrWhiteSpace(line)) _favoriteNames.Add(line.Trim());
            }

            RenderPlayers();
        }

        private void RenderPlayers()
        {
            pnlFavorites.Controls.Clear();
            pnlOthers.Controls.Clear();

            foreach (var p in _currentPlayers)
            {
                var isFav = _favoriteNames.Contains(p.Name);
                var pc = new PlayerControl(p, isFav, _assetsRoot);
                pc.ToggleFavorite += (s, e) => ToggleFavorite(((PlayerControl)s!).Player.Name);
                pc.MouseDown += (s, e) => DoDragDrop(pc, DragDropEffects.Move);

                if (isFav) pnlFavorites.Controls.Add(pc);
                else pnlOthers.Controls.Add(pc);
            }
        }

        private void ToggleFavorite(string name)
        {
            if (_favoriteNames.Contains(name)) _favoriteNames.Remove(name);
            else
            {
                if (_favoriteNames.Count >= 3)
                {
                    MessageBox.Show(L("MaxFavoritesMsg"), L("Limit"),
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _favoriteNames.Add(name);
            }

            File.WriteAllLines(favPlayersPath, _favoriteNames);
            RenderPlayers();
        }

        // ===== Drag & Drop =====
        private void pnl_DragEnter(object sender, DragEventArgs e) => e.Effect = DragDropEffects.Move;

        private void pnlFavorites_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data?.GetDataPresent(typeof(PlayerControl)) == true)
            {
                var pc = (PlayerControl)e.Data.GetData(typeof(PlayerControl))!;
                ToggleFavorite(pc.Player.Name);
            }
        }

        private void pnlOthers_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data?.GetDataPresent(typeof(PlayerControl)) == true)
            {
                var pc = (PlayerControl)e.Data.GetData(typeof(PlayerControl))!;
                if (_favoriteNames.Contains(pc.Player.Name))
                {
                    _favoriteNames.Remove(pc.Player.Name);
                    File.WriteAllLines(favPlayersPath, _favoriteNames);
                    RenderPlayers();
                }
            }
        }

        // ===== Rankings =====
        private async void btnGoals_Click(object sender, EventArgs e)
        {
            if (cmbTeams.SelectedItem == null) return;

            var code = cmbTeams.SelectedItem.ToString()!.Split('(')[1].TrimEnd(')');
            var ranking = await _svc.GetGoalRankingAsync(code);

            var dt = new DataTable();
            dt.Columns.Add(L("Player"));
            dt.Columns.Add(L("Goals"), typeof(int));
            foreach (var r in ranking) dt.Rows.Add(r.Player, r.Goals);

            gridRanking.DataSource = dt;
        }

        private async void btnYellows_Click(object sender, EventArgs e)
        {
            if (cmbTeams.SelectedItem == null) return;

            var code = cmbTeams.SelectedItem.ToString()!.Split('(')[1].TrimEnd(')');
            var ranking = await _svc.GetYellowCardRankingAsync(code);

            var dt = new DataTable();
            dt.Columns.Add(L("Player"));
            dt.Columns.Add(L("YellowCards"), typeof(int));
            foreach (var r in ranking) dt.Rows.Add(r.Player, r.YellowCards);

            gridRanking.DataSource = dt;
        }

        private async void btnAttendance_Click(object sender, EventArgs e)
        {
            if (cmbTeams.SelectedItem == null) return;

            var code = cmbTeams.SelectedItem.ToString()!.Split('(')[1].TrimEnd(')');
            var ranking = await _svc.GetAttendanceListAsync(code);

            var dt = new DataTable();
            dt.Columns.Add(L("Location"));
            dt.Columns.Add(L("AttendanceCol"), typeof(int));
            dt.Columns.Add(L("HomeVsAway"));
            foreach (var r in ranking) dt.Rows.Add(r.Location, r.Attendance, $"{r.Home} vs {r.Away}");

            gridRanking.DataSource = dt;
        }

        // ===== Print =====
        private void btnPrint_Click(object sender, EventArgs e)
        {
            using var pd = new PrintDialog();
            using var doc = new PrintDocument();

            doc.PrintPage += (s, ev) =>
            {
                int y = 40;
                ev.Graphics.DrawString(L("Ranking"),
                    new Font("Segoe UI", 12),
                    Brushes.Black, 40, 10);

                foreach (DataGridViewRow row in gridRanking.Rows)
                {
                    if (row.IsNewRow) continue;
                    string line = string.Join("  |  ", row.Cells
                        .Cast<DataGridViewCell>()
                        .Select(c => c.Value?.ToString() ?? ""));
                    ev.Graphics.DrawString(line,
                        new Font("Segoe UI", 9),
                        Brushes.Black, 40, y);
                    y += 20;
                    if (y > ev.MarginBounds.Bottom) { ev.HasMorePages = true; y = 40; }
                }
            };

            pd.Document = doc;
            if (pd.ShowDialog(this) == DialogResult.OK) doc.Print();
        }

        // ===== Settings (soft refresh; preserve Mode) =====
        private void btnSettings_Click(object sender, EventArgs e)
        {
            using var sf = new SettingsForm(_cfg);
            if (sf.ShowDialog(this) != DialogResult.OK) return;

            bool langChanged = _cfg.Language != sf.Config.Language;
            bool genderChanged = _cfg.Gender != sf.Config.Gender;

            // Build a new config that PRESERVES Mode (API vs LocalJson)
            _cfg = new DataConfig
            {
                Mode = _cfg.Mode,
                Gender = sf.Config.Gender,
                Language = sf.Config.Language,
                ApiBase = _cfg.ApiBase // keep same base
            };

            PersistSettings(_cfg);

            // Only rebuild service if gender changed (data source)
            if (genderChanged)
            {
                _svc = new WorldCupDataService(_cfg);
                cmbTeams.Items.Clear();
                gridRanking.DataSource = null;
                pnlFavorites.Controls.Clear();
                pnlOthers.Controls.Clear();
                _ = LoadTeamsAsync();
            }

            if (langChanged) ApplyLanguage(_cfg.Language);
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Close();            // Triggers your OnFormClosing confirmation
                return true;        // Mark as handled
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }


        // (Optional) Exit confirm using Localizer strings
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            var res = MessageBox.Show(L("ExitConfirm"), L("Confirm"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (res == DialogResult.No) { e.Cancel = true; }
            base.OnFormClosing(e);
        }
    }
}
