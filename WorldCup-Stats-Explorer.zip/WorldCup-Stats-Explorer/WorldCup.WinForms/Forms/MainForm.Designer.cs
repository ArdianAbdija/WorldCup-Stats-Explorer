namespace WorldCup.WinForms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ComboBox cmbTeams;
        private System.Windows.Forms.Button btnLoadPlayers;
        private System.Windows.Forms.FlowLayoutPanel pnlFavorites;
        private System.Windows.Forms.FlowLayoutPanel pnlOthers;
        private System.Windows.Forms.Button btnGoals;
        private System.Windows.Forms.Button btnYellows;
        private System.Windows.Forms.Button btnAttendance;
        private System.Windows.Forms.DataGridView gridRanking;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSettings;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.cmbTeams = new System.Windows.Forms.ComboBox();
            this.btnLoadPlayers = new System.Windows.Forms.Button();
            this.pnlFavorites = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlOthers = new System.Windows.Forms.FlowLayoutPanel();
            this.btnGoals = new System.Windows.Forms.Button();
            this.btnYellows = new System.Windows.Forms.Button();
            this.btnAttendance = new System.Windows.Forms.Button();
            this.gridRanking = new System.Windows.Forms.DataGridView();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridRanking)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbTeams
            // 
            this.cmbTeams.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTeams.FormattingEnabled = true;
            this.cmbTeams.Location = new System.Drawing.Point(12, 12);
            this.cmbTeams.Name = "cmbTeams";
            this.cmbTeams.Size = new System.Drawing.Size(300, 23);
            // 
            // btnLoadPlayers
            // 
            this.btnLoadPlayers.Location = new System.Drawing.Point(318, 12);
            this.btnLoadPlayers.Name = "btnLoadPlayers";
            this.btnLoadPlayers.Size = new System.Drawing.Size(120, 23);
            this.btnLoadPlayers.Text = "Load Players";
            this.btnLoadPlayers.UseVisualStyleBackColor = true;
            this.btnLoadPlayers.Click += new System.EventHandler(this.btnLoadPlayers_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.Location = new System.Drawing.Point(444, 12);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(80, 23);
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // pnlFavorites
            // 
            this.pnlFavorites.AllowDrop = true;
            this.pnlFavorites.AutoScroll = true;
            this.pnlFavorites.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFavorites.Location = new System.Drawing.Point(12, 50);
            this.pnlFavorites.Name = "pnlFavorites";
            this.pnlFavorites.Size = new System.Drawing.Size(512, 160);
            this.pnlFavorites.DragEnter += new System.Windows.Forms.DragEventHandler(this.pnl_DragEnter);
            this.pnlFavorites.DragDrop += new System.Windows.Forms.DragEventHandler(this.pnlFavorites_DragDrop);
            // 
            // pnlOthers
            // 
            this.pnlOthers.AllowDrop = true;
            this.pnlOthers.AutoScroll = true;
            this.pnlOthers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOthers.Location = new System.Drawing.Point(12, 216);
            this.pnlOthers.Name = "pnlOthers";
            this.pnlOthers.Size = new System.Drawing.Size(512, 160);
            this.pnlOthers.DragEnter += new System.Windows.Forms.DragEventHandler(this.pnl_DragEnter);
            this.pnlOthers.DragDrop += new System.Windows.Forms.DragEventHandler(this.pnlOthers_DragDrop);
            // 
            // btnGoals
            // 
            this.btnGoals.Location = new System.Drawing.Point(540, 50);
            this.btnGoals.Name = "btnGoals";
            this.btnGoals.Size = new System.Drawing.Size(120, 28);
            this.btnGoals.Text = "Goals Ranking";
            this.btnGoals.UseVisualStyleBackColor = true;
            this.btnGoals.Click += new System.EventHandler(this.btnGoals_Click);
            // 
            // btnYellows
            // 
            this.btnYellows.Location = new System.Drawing.Point(540, 84);
            this.btnYellows.Name = "btnYellows";
            this.btnYellows.Size = new System.Drawing.Size(120, 28);
            this.btnYellows.Text = "Yellow Cards";
            this.btnYellows.UseVisualStyleBackColor = true;
            this.btnYellows.Click += new System.EventHandler(this.btnYellows_Click);
            // 
            // btnAttendance
            // 
            this.btnAttendance.Location = new System.Drawing.Point(540, 118);
            this.btnAttendance.Name = "btnAttendance";
            this.btnAttendance.Size = new System.Drawing.Size(120, 28);
            this.btnAttendance.Text = "Attendance";
            this.btnAttendance.UseVisualStyleBackColor = true;
            this.btnAttendance.Click += new System.EventHandler(this.btnAttendance_Click);
            // 
            // gridRanking
            // 
            this.gridRanking.AllowUserToAddRows = false;
            this.gridRanking.AllowUserToDeleteRows = false;
            this.gridRanking.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridRanking.Location = new System.Drawing.Point(540, 160);
            this.gridRanking.Name = "gridRanking";
            this.gridRanking.ReadOnly = true;
            this.gridRanking.RowHeadersVisible = false;
            this.gridRanking.Size = new System.Drawing.Size(420, 216);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(540, 12);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(120, 23);
            this.btnPrint.Text = "Print Rankings";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 392);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.gridRanking);
            this.Controls.Add(this.btnAttendance);
            this.Controls.Add(this.btnYellows);
            this.Controls.Add(this.btnGoals);
            this.Controls.Add(this.pnlOthers);
            this.Controls.Add(this.pnlFavorites);
            this.Controls.Add(this.btnLoadPlayers);
            this.Controls.Add(this.cmbTeams);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WorldCup - WinForms";
            ((System.ComponentModel.ISupportInitialize)(this.gridRanking)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
