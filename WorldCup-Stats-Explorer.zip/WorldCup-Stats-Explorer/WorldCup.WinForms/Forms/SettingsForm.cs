using System;
using System.Windows.Forms;
using WorldCup.Data.Config;

namespace WorldCup.WinForms.Forms
{
    public partial class SettingsForm : Form
    {
        private readonly DataConfig _initial;
        public DataConfig Config { get; private set; }

        public SettingsForm(DataConfig cfg)
        {
            InitializeComponent();

            _initial = cfg ?? new DataConfig();
            Config = _initial;

            // Preselect current values
            cmbGender.SelectedIndex = _initial.Gender == Gender.Men ? 0 : 1;
            cmbLanguage.SelectedIndex = _initial.Language == Lang.Hr ? 1 : 0; // 0=EN, 1=HR
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            var selectedGender = (cmbGender.SelectedIndex == 1) ? Gender.Women : Gender.Men;
            var selectedLang = (cmbLanguage.SelectedIndex == 1) ? Lang.Hr : Lang.En;

            // Build NEW config while PRESERVING Mode + ApiBase
            Config = new DataConfig
            {
                Mode = _initial.Mode,
                ApiBase = _initial.ApiBase,
                Gender = selectedGender,
                Language = selectedLang
                // No LocalRoot override; DataConfig already defaults it.
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
