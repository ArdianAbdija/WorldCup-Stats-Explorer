using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WorldCup.Data.Models;

namespace WorldCup.WinForms.Controls
{
    public partial class PlayerControl : UserControl
    {
        public Player Player { get; private set; }
        public bool IsFavorite { get; private set; }

        public PlayerControl(Player p, bool favorite, string assetsDir)
        {
            InitializeComponent();
            Player = p;
            IsFavorite = favorite;
            lblName.Text = p.Name + (p.Captain ? " (C)" : "");
            lblInfo.Text = $"{p.Position}, #{p.ShirtNumber}";

            var def = Path.Combine(assetsDir, "default_player.png");
            if (File.Exists(def)) pic.Image = Image.FromFile(def);

            ContextMenuStrip cms = new ContextMenuStrip();
            var toggle = new ToolStripMenuItem(favorite ? "Remove from favorites" : "Add to favorites");
            toggle.Click += (s, e) => OnToggleFavorite();
            cms.Items.Add(toggle);
            this.ContextMenuStrip = cms;
        }

        public event EventHandler? ToggleFavorite;

        private void OnToggleFavorite()
        {
            ToggleFavorite?.Invoke(this, EventArgs.Empty);
        }

        private void PlayerControl_MouseDown(object? sender, MouseEventArgs e)
        {
            DoDragDrop(this, DragDropEffects.Move);
        }
    }
}
