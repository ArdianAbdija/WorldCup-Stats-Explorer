# World Cup Stats Explorer

A **C# / .NET 8 Windows desktop application** for exploring World Cup match and team data. This university project includes **two desktop UIs**—Windows Forms and WPF—built on a shared data-access library.

## Features

### Windows Forms app
- Select a national team and view players from its first available match.
- Organize favorite players using drag-and-drop.
- View player goal and yellow-card rankings and match attendance information.
- Print the displayed ranking table.
- Choose the men's or women's dataset and switch between English and Croatian.

### WPF app
- Select a team and opponent to view an available head-to-head match.
- Visualize starting lineups on a football pitch, with lineup and substitutes lists.
- Open player and team detail windows.
- Change language, tournament dataset, data source, and display settings.

### Shared data layer
- Fetch team and match information over HTTP and parse JSON responses.
- Read bundled local JSON files and fall back to local data if an API request fails.
- Use C# models and services shared between both desktop apps.

## Tech stack

- **Language:** C#
- **Framework:** .NET 8 (`net8.0-windows`)
- **Desktop UIs:** Windows Forms and Windows Presentation Foundation (WPF / XAML)
- **Data handling:** `HttpClient`, `System.Text.Json`, local JSON files
- **Development environment:** Visual Studio

## Project structure

```text
WorldCup.Data/                  Shared models, configuration and data providers
WorldCup.WinForms/              Windows Forms UI
WorldCup_WPF_Final_v3/
  WorldCup.WPF/                 WPF/XAML UI and view models
Assets/                         Image resources used by WinForms
WorldCup_Abdija.sln             Visual Studio solution
```

## Getting started

**Requirements:** Windows 10/11 and Visual Studio 2022 (with **.NET desktop development** workload), or the .NET 8 SDK with Windows desktop support.

1. Clone or download this repository.
2. Open `WorldCup_Abdija.sln` in Visual Studio.
3. In Solution Explorer, right-click **WorldCup.WPF** or **WorldCup.WinForms** and choose **Set as Startup Project**.
4. Build the solution and start the selected app using **F5**.

Alternatively, in a Windows terminal with .NET 8 installed:

```powershell
# WPF version
dotnet run --project "WorldCup_WPF_Final_v3/WorldCup.WPF/WorldCup.WPF.csproj"

# Windows Forms version
dotnet run --project "WorldCup.WinForms/WorldCup.WinForms.csproj"
```

> This is a **Windows-only desktop project**; it is not a website or a cross-platform app.

## Data sources and limitations

The application is configured to use a World Cup HTTP API (`https://worldcup-vua.nullbit.hr`) by default, with local JSON as a fallback. The bundled `worldcup.sfg.io` JSON files contain **small demonstration fixtures**, not a comprehensive historical World Cup dataset. As a result, the screens and rankings shown in local/fallback mode are limited by the available sample data. Availability and contents of the external API have not been verified for this GitHub upload.

## Screenshots

Authentic screenshots can be added after running the desktop applications on Windows. Suggested captures:

- `docs/screenshots/wpf-match-view.png` — match comparison and pitch/lineups
- `docs/screenshots/winforms-player-stats.png` — player lists and statistics
- `docs/screenshots/settings.png` — language, tournament, and data-source settings

Once captured, add these lines below this section:

```markdown
![WPF match view](docs/screenshots/wpf-match-view.png)
![Windows Forms statistics](docs/screenshots/winforms-player-stats.png)
```

## About

University project showcasing C# programming, event-driven desktop interfaces, WPF/XAML, Windows Forms, JSON data handling, and separation of UI and data-access concerns.

**Note:** This repository preserves the provided source code. A clean-up for source control has been performed, but no Windows build or end-to-end application run has been verified as part of this packaging step.
