using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using WorldCup.Data.Models;

namespace WorldCup.Data.Services
{
    public interface IDataProvider
    {
        Task<IReadOnlyList<TeamResult>> GetTeamResultsAsync(CancellationToken ct = default);
        Task<IReadOnlyList<Match>> GetMatchesAsync(CancellationToken ct = default);
        Task<IReadOnlyList<Match>> GetMatchesByCountryAsync(string fifaCode, CancellationToken ct = default);
    }
}
