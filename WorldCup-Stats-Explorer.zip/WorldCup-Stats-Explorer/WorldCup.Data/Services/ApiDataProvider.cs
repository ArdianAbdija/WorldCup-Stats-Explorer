﻿// WorldCup.Data/Services/ApiDataProvider.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using WorldCup.Data.Config;
using WorldCup.Data.Models;

namespace WorldCup.Data.Services
{
    public sealed class ApiDataProvider : IDataProvider
    {
        private readonly DataConfig _cfg;
        private readonly HttpClient _http;

        private static readonly JsonSerializerOptions JsonOpts = new()
        {
            PropertyNameCaseInsensitive = true
        };

        public ApiDataProvider(DataConfig cfg, HttpClient? http = null)
        {
            _cfg = cfg;
            _http = http ?? new HttpClient
            {
                BaseAddress = new Uri(cfg.ApiBase.TrimEnd('/') + "/")
            };
        }

        // DTO for /{gender}/teams response (snake_case fields)
        private sealed class ApiTeam
        {
            [JsonPropertyName("country")] public string? Country { get; set; }
            [JsonPropertyName("fifa_code")] public string? FifaCode { get; set; }
            // we ignore group fields; not needed for your UI
        }

        private async Task<T> GetAsync<T>(string relative, CancellationToken ct)
        {
            using var res = await _http.GetAsync(relative, ct);
            res.EnsureSuccessStatusCode();
            await using var s = await res.Content.ReadAsStreamAsync(ct);
            var obj = await JsonSerializer.DeserializeAsync<T>(s, JsonOpts, ct);
            if (obj == null) throw new HttpRequestException($"Empty payload for {relative}");
            return obj;
        }

        private async Task<T> GetFirstAvailableAsync<T>(IEnumerable<string> paths, CancellationToken ct)
        {
            Exception? last = null;
            foreach (var p in paths)
            {
                try { return await GetAsync<T>(p, ct); }
                catch (Exception ex) { last = ex; }
            }
            throw last ?? new HttpRequestException("No endpoint succeeded.");
        }

        // ---------------- IDataProvider ----------------

        // Prefer /teams/results; fall back to /teams and map to TeamResult
        public async Task<IReadOnlyList<TeamResult>> GetTeamResultsAsync(CancellationToken ct = default)
        {
            // endpoints that should already match TeamResult
            var teamResultsPaths = new[]
            {
                $"{_cfg.GenderPath}/teams/results",
                $"{_cfg.GenderPath}/teams/results.json",
                $"{_cfg.GenderPath}/results",
                $"{_cfg.GenderPath}/results.json"
            };

            try
            {
                var results = await GetFirstAvailableAsync<List<TeamResult>>(teamResultsPaths, ct);
                if (results.Count >= 2) return results; // sanity check
            }
            catch
            {
                // fall through to /teams mapping
            }

            // fallback: /teams -> TeamResult (Country + FifaCode only)
            var teamsPaths = new[]
            {
                $"{_cfg.GenderPath}/teams",
                $"{_cfg.GenderPath}/teams.json"
            };

            var teams = await GetFirstAvailableAsync<List<ApiTeam>>(teamsPaths, ct);

            var mapped = teams
                .Where(t => !string.IsNullOrWhiteSpace(t?.FifaCode))
                .GroupBy(t => t!.FifaCode!)
                .Select(g =>
                {
                    var t = g.First()!;
                    return new TeamResult
                    {
                        Country = t.Country ?? string.Empty,
                        FifaCode = g.Key
                        // no Group here (your TeamResult doesn't define it)
                    };
                })
                .OrderBy(tr => tr.Country)
                .ToList();

            return mapped;
        }

        public Task<IReadOnlyList<Match>> GetMatchesAsync(CancellationToken ct = default)
        {
            var paths = new[]
            {
                $"{_cfg.GenderPath}/matches",
                $"{_cfg.GenderPath}/matches.json"
            };
            return GetFirstAvailableAsync<List<Match>>(paths, ct)
                .ContinueWith<IReadOnlyList<Match>>(t => t.Result, ct);
        }

        public async Task<IReadOnlyList<Match>> GetMatchesByCountryAsync(string fifaCode, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(fifaCode))
                return Array.Empty<Match>();

            var directPaths = new[]
            {
                $"{_cfg.GenderPath}/matches/country?fifa_code={Uri.EscapeDataString(fifaCode)}",
                // some deployments may not support .json variant; included just in case:
                $"{_cfg.GenderPath}/matches/country.json?fifa_code={Uri.EscapeDataString(fifaCode)}"
            };

            try
            {
                var fromEndpoint = await GetFirstAvailableAsync<List<Match>>(directPaths, ct);
                if (fromEndpoint.Count > 0) return fromEndpoint;
            }
            catch
            {
                // fall back to filtering all matches
            }

            var all = await GetMatchesAsync(ct);
            return all.Where(m => m.HomeTeam?.Code == fifaCode || m.AwayTeam?.Code == fifaCode).ToList();
        }
    }
}
