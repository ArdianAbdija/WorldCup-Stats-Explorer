using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WorldCup.Data.Config;
using WorldCup.Data.Models;

namespace WorldCup.Data.Services
{
    /// <summary>
    /// Facade over an IDataProvider (API or File). When Mode == Api, it will
    /// automatically fall back to local JSON if the API call throws.
    /// </summary>
    public sealed class WorldCupDataService
    {
        public DataConfig Config { get; }
        private readonly IDataProvider _primary;
        private readonly IDataProvider? _fallback;

        public WorldCupDataService(DataConfig cfg)
        {
            // Choose primary provider from config; keep local file as fallback in API mode.
            Config = cfg;
            _primary = cfg.Mode == DataMode.Api ? new ApiDataProvider(cfg) : new FileDataProvider(cfg);
            _fallback = cfg.Mode == DataMode.Api ? new FileDataProvider(cfg) : null;
        }

        // Helper to call primary provider and, if it fails, use fallback (when present).
        private async Task<T> Use<T>(Func<IDataProvider, Task<T>> call)
        {
            try
            {
                return await call(_primary);
            }
            catch when (_fallback is not null)
            {
                return await call(_fallback!);
            }
        }

        // ----------------- Basic data access -----------------

        public Task<IReadOnlyList<TeamResult>> GetTeamResultsAsync(CancellationToken ct = default) =>
            Use(p => p.GetTeamResultsAsync(ct));

        public Task<IReadOnlyList<Match>> GetMatchesAsync(CancellationToken ct = default) =>
            Use(p => p.GetMatchesAsync(ct));

        public Task<IReadOnlyList<Match>> GetMatchesByCountryAsync(string fifaCode, CancellationToken ct = default) =>
            Use(p => p.GetMatchesByCountryAsync(fifaCode, ct));

        // ----------------- Helpers used by WinForms UI -----------------

        public async Task<IReadOnlyList<Player>> GetPlayersFromFirstMatchAsync(string fifaCode, CancellationToken ct = default)
        {
            var matches = await GetMatchesByCountryAsync(fifaCode, ct);
            var first = matches.Where(m => m.DateTime.HasValue)
                               .OrderBy(m => m.DateTime!.Value)
                               .FirstOrDefault();
            if (first == null) return new List<Player>();

            var stats = first.HomeTeam.Code == fifaCode
                ? first.HomeTeamStatistics
                : first.AwayTeamStatistics;

            if (stats == null) return new List<Player>();
            return stats.StartingEleven.Concat(stats.Substitutes).ToList();
        }

        public async Task<IReadOnlyList<(string Player, int Goals)>> GetGoalRankingAsync(string fifaCode, CancellationToken ct = default)
        {
            var matches = await GetMatchesByCountryAsync(fifaCode, ct);
            var counts = new Dictionary<string, int>(StringComparer.Ordinal);

            foreach (var match in matches)
            {
                var events = match.HomeTeam.Code == fifaCode ? match.HomeTeamEvents : match.AwayTeamEvents;
                if (events == null) continue;

                foreach (var ev in events)
                {
                    if (ev.TypeOfEvent == "goal" || ev.TypeOfEvent == "goal-penalty" || ev.TypeOfEvent == "goal-own")
                    {
                        if (!counts.ContainsKey(ev.Player)) counts[ev.Player] = 0;
                        counts[ev.Player]++;
                    }
                }
            }

            return counts.OrderByDescending(kv => kv.Value)
                         .Select(kv => (kv.Key, kv.Value))
                         .ToList();
        }

        public async Task<IReadOnlyList<(string Player, int YellowCards)>> GetYellowCardRankingAsync(string fifaCode, CancellationToken ct = default)
        {
            var matches = await GetMatchesByCountryAsync(fifaCode, ct);
            var counts = new Dictionary<string, int>(StringComparer.Ordinal);

            foreach (var match in matches)
            {
                var events = match.HomeTeam.Code == fifaCode ? match.HomeTeamEvents : match.AwayTeamEvents;
                if (events == null) continue;

                foreach (var ev in events)
                {
                    if (ev.TypeOfEvent == "yellow-card")
                    {
                        if (!counts.ContainsKey(ev.Player)) counts[ev.Player] = 0;
                        counts[ev.Player]++;
                    }
                }
            }

            return counts.OrderByDescending(kv => kv.Value)
                         .Select(kv => (kv.Key, kv.Value))
                         .ToList();
        }

        public async Task<IReadOnlyList<(string Location, int Attendance, string Home, string Away)>> GetAttendanceListAsync(string fifaCode, CancellationToken ct = default)
        {
            var matches = await GetMatchesByCountryAsync(fifaCode, ct);
            var list = new List<(string, int, string, string)>(matches.Count);

            foreach (var m in matches)
            {
                int.TryParse(m.Attendance ?? "0", out var att);
                list.Add((
                    m.Location,
                    att,
                    $"{m.HomeTeamCountry} ({m.HomeTeam.Code})",
                    $"{m.AwayTeamCountry} ({m.AwayTeam.Code})"
                ));
            }

            return list;
        }
    }
}
