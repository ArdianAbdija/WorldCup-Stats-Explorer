using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using WorldCup.Data.Config;
using WorldCup.Data.Models;

namespace WorldCup.Data.Services
{
    public sealed class FileDataProvider : IDataProvider
    {
        private readonly DataConfig _cfg;

        public FileDataProvider(DataConfig cfg)
        {
            _cfg = cfg ?? throw new ArgumentNullException(nameof(cfg));
        }

        private static readonly JsonSerializerOptions JsonOpts = new()
        {
            PropertyNameCaseInsensitive = true
        };

        private string DataFolder =>
            Path.Combine(_cfg.LocalRoot, _cfg.GenderPath);

        private string EnsureFile(params string[] relativeCandidates)
        {
            foreach (var rel in relativeCandidates)
            {
                var path = Path.Combine(DataFolder, rel);
                if (File.Exists(path)) return path;
            }
            throw new FileNotFoundException($"None of the files were found under '{DataFolder}': {string.Join(", ", relativeCandidates)}");
        }

        private static T? TryDeserialize<T>(string json)
        {
            try { return JsonSerializer.Deserialize<T>(json, JsonOpts); }
            catch { return default; }
        }

        // Minimal fallback DTO if teams.json doesn't match TeamResult exactly
        private sealed class TeamLite
        {
            [JsonPropertyName("country")] public string? Country { get; set; }
            [JsonPropertyName("fifa_code")] public string? FifaCode { get; set; }
        }

        public async Task<IReadOnlyList<TeamResult>> GetTeamResultsAsync(CancellationToken ct = default)
        {
            // Prefer teams.json (usually complete), then results.json
            var file = EnsureFile("teams.json", "results.json");
            var json = await File.ReadAllTextAsync(file, ct);

            // First try direct TeamResult[]
            var direct = TryDeserialize<List<TeamResult>>(json);
            if (direct is { Count: > 0 })
            {
                return direct
                    .Where(t => !string.IsNullOrWhiteSpace(t.FifaCode))
                    .GroupBy(t => t.FifaCode!)
                    .Select(g => g.First())
                    .OrderBy(t => t.Country)
                    .ToList();
            }

            // Fallback: map from TeamLite[]
            var lite = TryDeserialize<List<TeamLite>>(json) ?? new List<TeamLite>();
            var mapped = lite
                .Where(t => !string.IsNullOrWhiteSpace(t?.FifaCode))
                .GroupBy(t => t!.FifaCode!)
                .Select(g =>
                {
                    var t = g.First()!;
                    return new TeamResult
                    {
                        Country = t.Country ?? string.Empty,
                        FifaCode = g.Key
                    };
                })
                .OrderBy(tr => tr.Country)
                .ToList();

            return mapped;
        }

        public async Task<IReadOnlyList<Match>> GetMatchesAsync(CancellationToken ct = default)
        {
            var file = EnsureFile("matches.json");
            await using var s = File.OpenRead(file);
            var all = await JsonSerializer.DeserializeAsync<List<Match>>(s, JsonOpts, ct) ?? new();
            return all;
        }

        public async Task<IReadOnlyList<Match>> GetMatchesByCountryAsync(string fifaCode, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(fifaCode)) return Array.Empty<Match>();
            var all = await GetMatchesAsync(ct);
            return all.Where(m => m.HomeTeam?.Code == fifaCode || m.AwayTeam?.Code == fifaCode).ToList();
        }
    }
}
