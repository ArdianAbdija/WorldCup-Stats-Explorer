using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WorldCup.Data.Models
{
    public class TeamStatistics
    {
        [JsonPropertyName("country")] public string Country { get; set; } = "";
        [JsonPropertyName("tactics")] public string? Tactics { get; set; }
        [JsonPropertyName("starting_eleven")] public List<Player> StartingEleven { get; set; } = new();
        [JsonPropertyName("substitutes")] public List<Player> Substitutes { get; set; } = new();
    }
}
