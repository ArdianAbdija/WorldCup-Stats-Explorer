using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WorldCup.Data.Models
{
    public class TeamSummary
    {
        [JsonPropertyName("country")] public string Country { get; set; } = "";
        [JsonPropertyName("code")] public string Code { get; set; } = "";
        [JsonPropertyName("goals")] public int Goals { get; set; }
        [JsonPropertyName("penalties")] public int Penalties { get; set; }
    }

    public class Match
    {
        [JsonPropertyName("venue")] public string Venue { get; set; } = "";
        [JsonPropertyName("location")] public string Location { get; set; } = "";
        [JsonPropertyName("attendance")] public string? Attendance { get; set; }
        [JsonPropertyName("stage_name")] public string StageName { get; set; } = "";
        [JsonPropertyName("home_team_country")] public string HomeTeamCountry { get; set; } = "";
        [JsonPropertyName("away_team_country")] public string AwayTeamCountry { get; set; } = "";
        [JsonPropertyName("datetime")] public DateTime? DateTime { get; set; }

        [JsonPropertyName("home_team")] public TeamSummary HomeTeam { get; set; } = new();
        [JsonPropertyName("away_team")] public TeamSummary AwayTeam { get; set; } = new();

        [JsonPropertyName("home_team_events")] public List<TeamEvent> HomeTeamEvents { get; set; } = new();
        [JsonPropertyName("away_team_events")] public List<TeamEvent> AwayTeamEvents { get; set; } = new();

        [JsonPropertyName("home_team_statistics")] public TeamStatistics? HomeTeamStatistics { get; set; }
        [JsonPropertyName("away_team_statistics")] public TeamStatistics? AwayTeamStatistics { get; set; }
    }
}
