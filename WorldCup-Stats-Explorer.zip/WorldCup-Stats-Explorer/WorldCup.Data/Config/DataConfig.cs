using System;
using System.IO;

namespace WorldCup.Data.Config
{
    public enum Gender { Men, Women }
    public enum DataMode { Api, LocalJson }
    public enum Lang { En, Hr }

    public sealed class DataConfig
    {

        public DataMode Mode { get; init; } = DataMode.Api;
        public Gender Gender { get; init; } = Gender.Men;
        public Lang Language { get; init; } = Lang.En;
        //  Default to bin\<TFM>\worldcup.sfg.io
        public string ApiBase { get; init; } = "https://worldcup-vua.nullbit.hr";
        public string LocalRoot { get; init; } =
            Path.Combine(AppContext.BaseDirectory, "worldcup.sfg.io");

        internal string GenderPath => Gender == Gender.Men ? "men" : "women";
        internal string LangCode => Language == Lang.Hr ? "hr" : "en";
    }
}
